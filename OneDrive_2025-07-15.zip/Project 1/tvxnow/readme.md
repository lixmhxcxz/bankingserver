##### **Latest Updates:**

###### 15/07/2025

This current network isn't secure enough for me to be doing this but I am bcs i'm deleting this project today and taking it off the school's network ready for deployment.

But this file is useful and will describe how to use and update this repository in our documentation, this can be used for trainng people what to look out for but can be what they actually do.



##### **Licence:**
You have the right to alter the variables as you see fit. the amount and the currency may be changed **if needed.**
#### **Data, List**
> Variables: